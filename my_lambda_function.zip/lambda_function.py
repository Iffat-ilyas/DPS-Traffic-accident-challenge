import json
import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.preprocessing import LabelEncoder
import pickel
def lambda_handler(event, context):
    # Load the trained model (replace 'model.pkl' with the path to your trained model)
    model = pickle.load(open('DPS-Model.pkl', 'rb'))

    # Extract the year and month from the request body
    year = event['JAHR']
    month = event['MONAT']

    # Prepare input data for prediction
    input_data = pd.f_df({
        'Category': [-1],  # Replace with the appropriate category encoding
        'Accident_type': [-1],  # Replace with the appropriate accident type encoding
        'Year': [JAHR],
        'Month': [MONAT]
    })

    # Make prediction
    prediction = model.predict(input_data)

    # Return the prediction as a response
    response = {
        'prediction': prediction[0]
    }

    return {
        'statusCode': 200,
        'body': json.dumps(response)
    }
